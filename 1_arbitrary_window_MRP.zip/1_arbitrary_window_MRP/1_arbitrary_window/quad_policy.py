## this file is a package for policy search for quadrotor

from quad_OC import OCSys
from quad_model import *
from casadi import *
import numpy as np
from solid_geometry import *
from math import pi

## transfer the Rodrigues parameters to rotation pair
def Rd2Rp(tra_ang):
    theta = 2*math.atan(magni(tra_ang))
    vector = norm(tra_ang+np.array([1e-8,0,0]))
    return [theta,vector]


## define the class to solve the policy search problem
## we should define the initial state, goal state and shape of narrow window. visualization wing length can also be determined.
class run_quad:
    def __init__(self, goal_pos = [0, 5, 0], goal_atti = [0,[1,0,0]], ini_r=[0,-5,0]\
            ,ini_v_I = [0.0, 0.0, 0.0], ini_q = rp2rd(0.0,[3,3,5]),horizon = 40\
            ,point1 = [-0.5,0, 0.5],point2 = [0.5,0,0.5],point3 = [0.5,0,-0.5],point4 = [-0.5,0,-0.5]):
        ## definition 
        self.winglen = 0.25
        # goal
        self.goal_pos = goal_pos
        self.goal_atti = goal_atti 
        # initial
        self.ini_r = ini_r
        self.ini_v_I = ini_v_I 
        self.ini_q = ini_q 
        self.ini_state = self.ini_r + self.ini_v_I + self.ini_q
        # set horizon
        self.horizon = horizon
        # set obstacle
        self.point1 = point1
        self.point2 = point2
        self.point3 = point3
        self.point4 = point4        
        ## define the class of the narrow window
        self.obstacle1 = obstacle(self.point1,self.point2,self.point3,self.point4)

        # --------------------------- create model1 ----------------------------------------
        self.uav1 = Quadrotor()
        self.uav1.initDyn(mass=0.9,l=0.25)
        self.uav1.initCost(wrt=3,wqt=60,wthrust=0.1,wrf=5,wvf=5,wqf=0,goal_pos=self.goal_pos)
        self.uav1.init_TraCost()

        # --------------------------- create PDP object1 ----------------------------------------
        # create a pdp object
        self.dt = 0.1
        self.uavoc1 = OCSys()
        self.uavoc1.setAuxvarVariable()
        self.uavoc1.setStateVariable(self.uav1.X)
        self.uavoc1.setControlVariable(self.uav1.U,control_lb=[-2*pi,-2*pi,-2*pi,0],control_ub=[2*pi,2*pi,2*pi,50])
        self.uavoc1.setDyn(self.uav1.f,self.dt)
        self.uavoc1.setthrustcost(self.uav1.thrust_cost)
        self.uavoc1.setPathCost(self.uav1.goal_cost)
        self.uavoc1.setTraCost(self.uav1.tra_cost)
        self.uavoc1.setFinalCost(self.uav1.final_cost)

    # return the reward of one trajectory determined by one set of high-level parameters
    def objective( self, tra_pos,tra_ang,t = 3):
        t = int(10*t)/10
        tra_atti = Rd2Rp(tra_ang)
        ## transfer the high-level parameters to traversal cost
        # define traverse cost
        self.uav1.init_TraCost(tra_pos,tra_atti)
        self.uavoc1.setTraCost(self.uav1.tra_cost, t)
        # obtain solution of trajectory
        sol1 = self.uavoc1.ocSolver(ini_state=self.ini_state, horizon=self.horizon,dt=self.dt)
        state_traj1 = sol1['state_traj_opt']
        self.traj = self.uav1.get_quadrotor_position(wing_len = self.winglen, state_traj = state_traj1)
        # calculate trajectory reward
        self.collision = 0
        self.path = 0
        ## detect whether there is detection
        self.co = 0
        for c in range(4):
            self.collision += self.obstacle1.collis_det(self.traj[:,3*(c+1):3*(c+2)],self.horizon)
            self.co += self.obstacle1.co 
        for p in range(self.horizon):
            self.path += np.dot(self.traj[p,0:3]-self.goal_pos, self.traj[p,0:3]-self.goal_pos)
        reward = 4000 * self.collision - 0.0005 * self.path + 100
        return reward
    # --------------------------- solution and learning----------------------------------------
    ##solution and demo ## learn the optimal high-level parameters
    def optimize(self, t):
        tra_pos = self.obstacle1.centroid
        tra_posx = self.obstacle1.centroid[0]
        tra_posy = self.obstacle1.centroid[1]
        tra_posz = self.obstacle1.centroid[2]
        tra_a = 0
        tra_b = 0
        tra_c = 0
        trace_a = []
        trace_b = []
        trace_c = []
        trace_x = []
        trace_y = []
        trace_z = []
        trace_t = []
        trace_loss = []
        tra_ang = np.array([tra_a,tra_b,tra_c])
        ## fixed perturbation to calculate the gradient
        for k in range(100):
            j = self.objective (tra_pos,tra_ang,t)
            drdx = np.clip(self.objective(tra_pos+[0.001,0,0],tra_ang=tra_ang, t=t) - j,-0.5,0.5)
            drdy = np.clip(self.objective(tra_pos+[0,0.001,0],tra_ang=tra_ang, t=t) - j,-0.5,0.5)
            drdz = np.clip(self.objective(tra_pos+[0,0,0.001],tra_ang=tra_ang, t=t) - j,-0.5,0.5)
            drda = np.clip(self.objective(tra_pos,tra_ang=tra_ang+[0.001,0,0], t=t) - j,-0.5,0.5)
            drdb = np.clip(self.objective(tra_pos,tra_ang=tra_ang+[0,0.001,0], t=t) - j,-0.5,0.5)
            drdc = np.clip(self.objective(tra_pos,tra_ang=tra_ang+[0,0,0.001], t=t) - j,-0.5,0.5)
            #drdt = np.clip(self.objective(tra_pos,tra_ang,t-0.1)-j,-10,10)
            # update
            tra_posx += 0.01*drdx
            tra_posy += 0.01*drdy
            tra_posz += 0.01*drdz
            tra_a += (0.1/(500*tra_a**2+5))*drda
            tra_b += (0.1/(500*tra_b**2+5))*drdb
            tra_c += (0.1/(500*tra_c**2+5))*drdc
            if((self.objective(tra_pos,tra_ang,t-0.1)-j)>2):
                t = t-0.1
            if((self.objective(tra_pos,tra_ang,t+0.1)-j)>2):
                t = t+0.1
            t = round(t,1)
            tra_pos = np.array([tra_posx,tra_posy,tra_posz])
            tra_ang = np.array([tra_a,tra_b,tra_c])
            print(str(j)+str('  ')+str(tra_pos)+str('  ')+str(tra_ang)+str('  ')+str(t)+str('  ')+str(k))
            trace_a += [tra_a]
            trace_b += [tra_b]
            trace_c += [tra_c]
            trace_x += [tra_posx]
            trace_y += [tra_posy]
            trace_z += [tra_posz]
            trace_t += [t]
            trace_loss += [100-j]
        ## demo the learning process
        fig = plt.figure(5)
        fig.suptitle('parameters vs iterations')
        ax1 = fig.add_subplot(5,1,1)
        ax1.plot(trace_x,color = 'r', label = 'px')
        ax1.legend()
        ax2 = fig.add_subplot(5,1,2)
        ax2.plot(trace_y,color = 'y', label = 'py')
        ax2.legend()
        ax3 = fig.add_subplot(5,1,3)
        ax3.plot(trace_z,color = 'b', label = 'pz')
        ax3.legend()
        ax4 = fig.add_subplot(5,1,4)
        ax4.plot(trace_a,color = 'r', label = 'a')
        ax4.plot(trace_b,color = 'y', label = 'b')
        ax4.plot(trace_c,color = 'b', label = 'c')
        ax4.title.set_text('traversal attitude')
        ax4.legend()
        ax5 = fig.add_subplot(5,1,5)
        ax5.plot(trace_t,color = 'r', label = 't_tra')
        ax5.title.set_text('traversal time')
        plt.show()
        plt.plot(trace_loss,color='b')
        plt.title('loss vs iterations')
        plt.show()

        return [t,tra_posx,tra_posy,tra_posz,tra_a, tra_b,tra_c, j,self.collision,self.path]


    ## use random perturbations to calculate the gradient and update(not recommonded)
    def LSFD(self,t):
        tra_posx = self.obstacle1.centroid[0]
        tra_posy = self.obstacle1.centroid[1]
        tra_posz = self.obstacle1.centroid[2]
        tra_a = 0
        tra_b = 0
        tra_c = 0
        current_para = np.array([tra_posx,tra_posy,tra_posz,tra_a,tra_b,tra_c])
        lr = np.array([2e-4,2e-4,2e-4,5e-5,5e-5,5e-5])
        for k in range(50):
            j = self.objective(current_para[0:3],current_para[3:6],t)
            # calculate derivatives
            c = []
            f = []
            for i in range(24):
                dx = sample(0.001)
                dr = self.objective (current_para[0:3]+dx[0:3],current_para[3:6]+dx[3:6],t)-j
                c += [dx]
                f += [dr]
            # update
            cm = np.array(c)
            fm = np.array(f)
            a = np.matmul(np.linalg.inv(np.matmul(cm.T,cm)),cm.T)
            drdx = np.matmul(a,fm)
            current_para = current_para + lr * drdx
            j = self.objective(current_para[0:3],current_para[3:6],t)
            if((self.objective(current_para[0:3],current_para[3:6],t+0.1)-j)>20):
                t = t + 0.1
            else:
                if((self.objective(current_para[0:3],current_para[3:6],t-0.1)-j)>20):
                    t = t - 0.1
            t = round(t,1) 
            print(str(t)+str('  ')+str(drdx)+str('  ')+str(k))
        return [current_para, j,self.collision,self.path]        


    ## play the animation for one set of high-level paramters of such a scenario
    def play_ani(self, tra_pos,tra_ang, t = 3):
        tra_atti = Rd2Rp(tra_ang)
        self.uav1.init_TraCost(tra_pos,tra_atti)
        self.uavoc1.setTraCost(self.uav1.tra_cost,t)
        self.sol1 = self.uavoc1.ocSolver(ini_state=self.ini_state, horizon=self.horizon,dt=self.dt)
        ## obtain the trajectory
        state_traj1 = self.sol1['state_traj_opt']
        traj = self.uav1.get_quadrotor_position(wing_len = self.winglen, state_traj = state_traj1)
        ## plot the animation
        self.uav1.play_animation(wing_len = self.winglen, state_traj = state_traj1,dt=self.dt, point1 = self.point1,\
            point2 = self.point2, point3 = self.point3, point4 = self.point4)
    
    def get_input(self, ini_state,tra_pos, tra_ang, t, Ulast): # added by Wang Bingheng, May 25th, 2022
        tra_atti = Rd2Rp(tra_ang)
        # initialize the NLP problem
        self.uav1.init_TraCost(tra_pos,tra_atti)
        self.uavoc1.setTraCost(self.uav1.tra_cost,t)
        ## obtain the solution
        self.sol1 = self.uavoc1.ocSolver(ini_state=ini_state,horizon=self.horizon,dt=self.dt, Ulast=Ulast)
        # obtain the control command
        control = self.sol1['control_traj_opt'][0,:]
        return control


## sample the perturbation (only for random perturbations)
def sample(deviation):
    act = np.random.normal(0,deviation,size=6)
    return act