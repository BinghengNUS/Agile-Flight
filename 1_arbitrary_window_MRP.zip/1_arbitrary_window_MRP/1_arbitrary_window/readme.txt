this folder learns the optimal high-level parameters to enable the quadrotor to traverse through arbitrary narrow window (quadrilateral)

quad_model.py: 
define the class of the model of the quadrotor 

quad_OC.py:
use 'casadi' to solve for a MPC problem.

solid_geometry:
define planes and lines to do collision detection

quad_policy.py:
use gradient descent policy search method to learn the optimal high-level parameters

quad_mpc9.py:
main function to learn the high-level parameters of a certain circumstances. we should indicate the initial state, goal position, and four vertexes of the narrow window.
