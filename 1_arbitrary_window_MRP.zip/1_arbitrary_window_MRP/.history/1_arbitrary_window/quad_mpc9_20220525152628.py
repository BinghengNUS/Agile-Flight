## mpc8.0
## this folder tries to tune higher parameters to make trajectory smoother

from quad_policy import *

## define the narrow window, others remain the default
quad1 = run_quad(point1 = [-0.5,0, 0.5],point2 = [-0.3,0,0.6],point3 = [-0.3,0,0.5],point4 = [-0.5,0,0.4])

# Implementing MPC in receding horizon manner, added by Wang Bingheng, May 25th, 2022
horizon = 40
quad1.uav1.setDyn(quad1.dt)
# initialization
state = quad1.ini_state
state_n = [state]
u = [0,0,0,0]
control_n = [u]
for i in range(horizon):
    u = quad1.get_input(state,[-4.51535303e-01, -2.33792041e-04 , 5.26563852e-01],[0.0242507 , 0.04983589, 0.01478296],1.0-i*quad1.dt) # tra_time = remaining time needed for passing througth the gate
    state = np.array(quad1.uav1.dyn_fn(state, u)).reshape(9)
    state_n = np.concatenate((state_n,[state]),axis = 0)
    control_n = np.concatenate((control_n,[u]),axis = 0)

# quad1.play_ani([-4.51535303e-01, -2.33792041e-04 , 5.26563852e-01] , [0.0242507 , 0.04983589, 0.01478296],  1.0)
quad1.uav1.play_animation(wing_len=quad1.winglen ,state_traj=state_n, dt=quad1.dt, point1=quad1.point1,
                         point2=quad1.point2, point3=quad1.point3, point4=quad1.point4)
## plot the control commands
quad1.uav1.plot_input(control_traj=quad1.sol1['control_traj_opt'],dt=0.1)
quad1.uav1.plot_rd(state_traj=quad1.sol1['state_traj_opt'],dt=0.1)

# quad1.uav1.plot_input(control_traj=control_n,dt=0.1)
# quad1.uav1.plot_rd(state_traj=state_n,dt=0.1)
