"""
Copy and paste the content of this file in the main function (mode 2) of the ROS code
=====================================================================================
Interface data:
--------------
Input (from ROS): position, velocity (both in inertial frame), and quaternion
Output (to ROS): total thrust and angular velocity (in body frame) 
=====================================================================================
Wang, Bingheng, May 25th, 2022
"""
