import numpy as np

a = [0,0,2]
b = [2,3,4]
c = [1,2,3]
d = a + b + c
print('d=',d)