import numpy as np

x        = 0 # replace the right-hand-side with the corresponding ROS topic
y        = 0
z        = 0
position = [x,y,z] 
# get velocity from ROS
vx       = 0
vy       = 0
vz       = 0
velocity = [vx,vy,vz]
# get quaternion from ROS
q0       = 0 # corresponds to pose.orientation.x
q1       = 0 # corresponds to pose.orientation.y
q2       = 0 # corresponds to pose.orientation.z
q3       = 1 # corresponds to pose.orientation.w
q        = [q3, q0, q1, q2]
# convert to Rodrigues parameters
rd       = [q0/q3,q1/q3,q2/q3]
# system state (9 dimensions)
state    = position + velocity + rd
print('state=',state)
print('px=',position[0])