## mpc8.0
## this folder tries to tune higher parameters to make trajectory smoother

from quad_policy import *

## define the narrow window, others remain the default
quad1 = run_quad(point1 = [-0.5,0, 0.5],point2 = [-0.3,0,0.6],point3 = [-0.3,0,0.5],point4 = [-0.5,0,0.4])

## optimize

# quad1.optimize(t = 2)

## obatin the optimal trajectory and play the animation
# quad1.play_ani(    [-3.07214895 , 7.82460701 , 1.14975092] , [ 0.20942024 ,-0.28220318 , 0.27687835] , 3.1    )
# quad1.play_ani(   [-2.87682718,  7.75372768,  1.05639432] , [ 0.1041662,  -0.35868954,  0.2385586 ],  3.1  )
quad1.play_ani([-4.51535303e-01, -2.33792041e-04 , 5.26563852e-01] , [0.0242507 , 0.04983589, 0.01478296],  1.0)

## plot the control commands
quad1.uav1.plot_input(control_traj=quad1.sol1['control_traj_opt'],dt=0.1)
quad1.uav1.plot_rd(state_traj=quad1.sol1['state_traj_opt'],dt=0.1)
