import numpy as np

a = np.array([[4,4,0],[0,5,5],[2,6,2]])
c = np.array([1,1,1])
b = np.matmul(np.linalg.inv(a),c)
print(b)