##this file is to generate model of quadrotor

from casadi import *
import casadi
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math
from math import sqrt

# quadrotor (UAV) environment
class Quadrotor:
    def __init__(self, project_name='my UAV'):
        self.project_name = 'my uav'

        # define the state of the quadrotor
        rx, ry, rz = SX.sym('rx'), SX.sym('ry'), SX.sym('rz')
        self.r_I = vertcat(rx, ry, rz)
        vx, vy, vz = SX.sym('vx'), SX.sym('vy'), SX.sym('vz')
        self.v_I = vertcat(vx, vy, vz)
        # MRP attitude of B w.r.t. I
        a, b, c = SX.sym('a'), SX.sym('b'), SX.sym('c')
        self.q = vertcat(a, b, c)

        # define the quadrotor input
        wx, wy, wz, thrust = SX.sym('wx'), SX.sym('wy'), SX.sym('wz'), SX.sym('thrust'), 
        self.w_B = vertcat(wx, wy, wz)
        self.thrust =  vertcat(thrust)

    def initDyn(self, mass=None, l=None):
        # global parameter
        g = 9.8

        # parameters settings
        parameter = []

        if mass is None:
            self.mass = SX.sym('mass')
            parameter += [self.mass]
        else:
            self.mass = mass

        if l is None:
            self.l = SX.sym('l')
            parameter += [self.l]
        else:
            self.l = l

        self.dyn_auxvar = vcat(parameter)


        # Gravity
        self.g_I = vertcat(0, 0, -g)
        # Mass of rocket, assume is little changed during the landing process
        self.m = self.mass

        # total thrust in body frame
        thrust = self.thrust
        self.thrust_B = vertcat(0, 0, thrust)

        # Mx = self.T_B[0] * sqrt(2)*self.l / 4 -self.T_B[1] * sqrt(2)*self.l / 4 - self.T_B[2] * sqrt(2)*self.l / 4 + self.T_B[3] * sqrt(2)*self.l / 4
        # My = -self.T_B[0] * sqrt(2)*self.l / 4 -self.T_B[1] * sqrt(2)*self.l / 4 + self.T_B[2] * sqrt(2)*self.l / 4 + self.T_B[3] * sqrt(2)*self.l / 4
        # Mz = (self.T_B[0] - self.T_B[1] + self.T_B[2] - self.T_B[3]) * self.c
        # self.M_B = vertcat(Mx, My, Mz)

        # cosine directional matrix
        C_I_B = self.q2R(self.q)  # body to inertial

        # Newton's law
        dr_I = self.v_I
        dv_I = 1 / self.m * mtimes(C_I_B, self.thrust_B) + self.g_I
        # Euler's law
        dq = mtimes(self.jaco(self.q), self.w_B)

        self.X = vertcat(self.r_I, self.v_I, self.q)
        self.U = vertcat(self.w_B, self.thrust)
        self.f = vertcat(dr_I, dv_I, dq)
    
    def setDyn(self, dt):       

        self.dyn = self.X + dt * self.f
        self.dyn_fn = casadi.Function('dynamics', [self.X, self.U], [self.dyn])

    ## define the thrust cost and final cost
    def initCost(self, wrt=None, wqt=None, wrf=None, wvf=None, wqf=None, \
        wthrust=0.1,goal_pos=[0,9,5],goal_atti=[0,[1,0,0]]):
        #traverse
        parameter = []
        if wrt is None:
            self.wrt = SX.sym('wrt')
            parameter += [self.wr]
        else:
            self.wrt = wrt

        if wqt is None:
            self.wqt = SX.sym('wqt')
            parameter += [self.wq]
        else:
            self.wqt = wqt

        #path
        if wrf is None:
            self.wrf = SX.sym('wrf')
            parameter += [self.wrf]
        else:
            self.wrf = wrf
        
        if wvf is None:
            self.wvf = SX.sym('wvf')
            parameter += [self.wvf]
        else:
            self.wvf = wvf
        
        if wqf is None:
            self.wqf = SX.sym('wqf')
            parameter += [self.wqf]
        else:
            self.wqf = wqf

        self.cost_auxvar = vcat(parameter)

        ## goal error
        # goal position in the world frame
        self.goal_r_I = goal_pos
        self.cost_r_I_g = dot(self.r_I - self.goal_r_I, self.r_I - self.goal_r_I)

        # goal velocity error
        goal_velo = [0, 0, 0]
        self.goal_v_I = goal_velo
        self.cost_v_I_g = dot(self.v_I - self.goal_v_I, self.v_I - self.goal_v_I)

        # final attitude error
        self.goal_q = rp2rd(goal_atti[0],goal_atti[1])
        goal_R_I = self.q2R(self.goal_q)
        R_I = self.q2R(self.q)
        self.cost_q_g = trace(np.identity(3) - mtimes(transpose(goal_R_I), R_I))

        # the thrust cost
        self.cost_thrust = dot(self.U, self.U)

        self.thrust_cost = wthrust * self.cost_thrust

        # the goal (final) cost
        self.goal_cost = self.wrf * self.cost_r_I_g + \
                         self.wvf * self.cost_v_I_g + \
                         self.wqf * self.cost_q_g 
        self.final_cost = self.wrf * self.cost_r_I_g + \
                          self.wvf * self.cost_v_I_g + \
                          self.wqf * self.cost_q_g

    ## define the traversal cost (for convenience, smoothness cost is define in 'quad_OC.py' file)
    def init_TraCost(self, tra_pos = [0, 0, 5], tra_atti = [0.7,[0,1,0]]):
        ## traverse cost
        # traverse position in the world frame
        self.tra_r_I = tra_pos[0:3]
        self.cost_r_I_t = dot(self.r_I - self.tra_r_I, self.r_I - self.tra_r_I)

        # traverse attitude error
        self.tra_q = rp2rd(tra_atti[0],tra_atti[1])
        tra_R_I = self.q2R(self.tra_q)
        R_I = self.q2R(self.q)
        self.cost_q_t = trace(np.identity(3) - mtimes(transpose(tra_R_I), R_I))

        self.tra_cost =   self.wrt * self.cost_r_I_t + \
                            self.wqt * self.cost_q_t



    ## below functions are for demo
    ## get the position of the centroid and the four vertexes of the quadrotor within a trajectory
    def get_quadrotor_position(self, wing_len, state_traj):

        # thrust_position in body frame
        r1 = vertcat(wing_len*0.5 / sqrt(2), wing_len*0.5 / sqrt(2), 0)
        r2 = vertcat(wing_len*0.5 / sqrt(2), -wing_len*0.5 / sqrt(2), 0)
        r3 = vertcat(-wing_len*0.5 / sqrt(2), -wing_len*0.5 / sqrt(2), 0)
        r4 = vertcat(-wing_len*0.5 / sqrt(2), wing_len*0.5 / sqrt(2), 0)

        # horizon
        horizon = np.size(state_traj, 0)
        position = np.zeros((horizon, 15))
        for t in range(horizon):
            # position of COM
            rc = state_traj[t, 0:3]
            # altitude of quaternion
            q = state_traj[t, 6:9]

            # direction cosine matrix from body to inertial
            CIB = self.q2R(q).full()

            # position of each rotor in inertial frame
            r1_pos = rc + mtimes(CIB, r1).full().flatten()
            r2_pos = rc + mtimes(CIB, r2).full().flatten()
            r3_pos = rc + mtimes(CIB, r3).full().flatten()
            r4_pos = rc + mtimes(CIB, r4).full().flatten()

            # store
            position[t, 0:3] = rc
            position[t, 3:6] = r1_pos
            position[t, 6:9] = r2_pos
            position[t, 9:12] = r3_pos
            position[t, 12:15] = r4_pos

        return position
    
    ## get the final position of the centroid and the four vertexes of the quadrotor within a trajectory
    def get_final_position(self,wing_len, p= None,q = None):
        p = self.tra_r_I
        q = self.tra_q
        r1 = vertcat(wing_len*0.5 / sqrt(2), wing_len*0.5 / sqrt(2), 0)
        r2 = vertcat(-wing_len*0.5 / sqrt(2), wing_len*0.5 / sqrt(2), 0)
        r3 = vertcat(-wing_len*0.5 / sqrt(2), -wing_len*0.5 / sqrt(2), 0)
        r4 = vertcat(wing_len*0.5 / sqrt(2), -wing_len*0.5 / sqrt(2), 0)

        CIB = self.q2R(q)
 
        r1_pos = p + mtimes(CIB, r1).full().flatten()   
        r2_pos = p + mtimes(CIB, r2).full().flatten()
        r3_pos = p + mtimes(CIB, r3).full().flatten()
        r4_pos = p + mtimes(CIB, r4).full().flatten()

        position = np.zeros(15)
        position[0:3] = p
        position[3:6] = r1_pos
        position[6:9] = r2_pos
        position[9:12] = r3_pos
        position[12:15] = r4_pos

        return position

    def play_animation(self, wing_len, state_traj, state_traj_ref=None, dt=0.1, \
            point1 = None,point2 = None,point3 = None,point4 = None,save_option=0, title='UAV Maneuvering'):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.set_xlabel('X (m)', fontsize=10, labelpad=5)
        ax.set_ylabel('Y (m)', fontsize=10, labelpad=5)
        ax.set_zlabel('Z (m)', fontsize=10, labelpad=5)
        ax.set_zlim(0, 1)
        ax.set_ylim(-5, 5)
        ax.set_xlim(-1, 1)
        ax.set_title(title, pad=20, fontsize=15)

        # target landing point
        ax.scatter3D([self.goal_r_I[0]], [self.goal_r_I[1]], [self.goal_r_I[2]], c="r", marker="x")
        
        ##plot the final state
        #final_position = self.get_final_position(wing_len=wing_len)
        #c_x, c_y, c_z = final_position[0:3]
        #r1_x, r1_y, r1_z = final_position[3:6]
        #r2_x, r2_y, r2_z = final_position[6:9]
        #r3_x, r3_y, r3_z = final_position[9:12]
        #r4_x, r4_y, r4_z = final_position[12:15]
        #line_arm1, = ax.plot([c_x, r1_x], [c_y, r1_y], [c_z, r1_z], linewidth=2, color='grey', marker='o', markersize=3)
        #line_arm2, = ax.plot([c_x, r2_x], [c_y, r2_y], [c_z, r2_z], linewidth=2, color='grey', marker='o', markersize=3)
        #line_arm3, = ax.plot([c_x, r3_x], [c_y, r3_y], [c_z, r3_z], linewidth=2, color='grey', marker='o', markersize=3)
        #line_arm4, = ax.plot([c_x, r4_x], [c_y, r4_y], [c_z, r4_z], linewidth=2, color='grey', marker='o', markersize=3)
        
        # plot gate
        ax.plot([point1[0],point2[0]],[point1[1],point2[1]],[point1[2],point2[2]],linewidth=1,color='red',linestyle='-')
        ax.plot([point2[0],point3[0]],[point2[1],point3[1]],[point2[2],point3[2]],linewidth=1,color='red',linestyle='-')
        ax.plot([point3[0],point4[0]],[point3[1],point4[1]],[point3[2],point4[2]],linewidth=1,color='red',linestyle='-')
        ax.plot([point4[0],point1[0]],[point4[1],point1[1]],[point4[2],point1[2]],linewidth=1,color='red',linestyle='-')
        # data
        position = self.get_quadrotor_position(wing_len, state_traj)
        sim_horizon = np.size(position, 0)

        if state_traj_ref is None:
            position_ref = self.get_quadrotor_position(0, numpy.zeros_like(position))
        else:
            position_ref = self.get_quadrotor_position(wing_len, state_traj_ref)


        ## plot the process
        #for i in range(8):
        #    c_x, c_y, c_z = position[i*8,0:3]
        #    r1_x, r1_y, r1_z = position[i*8,3:6]
        #    r2_x, r2_y, r2_z = position[i*8,6:9]
        #    r3_x, r3_y, r3_z = position[i*8,9:12]
        #    r4_x, r4_y, r4_z = position[i*8,12:15]
        #    line_arm1, = ax.plot([c_x, r1_x], [c_y, r1_y], [c_z, r1_z], linewidth=2, color='grey', marker='o', markersize=3)
        #    line_arm2, = ax.plot([c_x, r2_x], [c_y, r2_y], [c_z, r2_z], linewidth=2, color='grey', marker='o', markersize=3)
        #    line_arm3, = ax.plot([c_x, r3_x], [c_y, r3_y], [c_z, r3_z], linewidth=2, color='grey', marker='o', markersize=3)
        #    line_arm4, = ax.plot([c_x, r4_x], [c_y, r4_y], [c_z, r4_z], linewidth=2, color='grey', marker='o', markersize=3)

        # animation
        line_traj, = ax.plot(position[:1, 0], position[:1, 1], position[:1, 2])
        c_x, c_y, c_z = position[0, 0:3]
        r1_x, r1_y, r1_z = position[0, 3:6]
        r2_x, r2_y, r2_z = position[0, 6:9]
        r3_x, r3_y, r3_z = position[0, 9:12]
        r4_x, r4_y, r4_z = position[0, 12:15]
        line_arm1, = ax.plot([c_x, r1_x], [c_y, r1_y], [c_z, r1_z], linewidth=0.7, color='red', marker='o', markersize=1)
        line_arm2, = ax.plot([c_x, r2_x], [c_y, r2_y], [c_z, r2_z], linewidth=0.7, color='blue', marker='o', markersize=1)
        line_arm3, = ax.plot([c_x, r3_x], [c_y, r3_y], [c_z, r3_z], linewidth=0.7, color='orange', marker='o', markersize=1)
        line_arm4, = ax.plot([c_x, r4_x], [c_y, r4_y], [c_z, r4_z], linewidth=0.7, color='green', marker='o', markersize=1)

        line_traj_ref, = ax.plot(position_ref[:1, 0], position_ref[:1, 1], position_ref[:1, 2], color='gray', alpha=0.5)
        c_x_ref, c_y_ref, c_z_ref = position_ref[0, 0:3]
        r1_x_ref, r1_y_ref, r1_z_ref = position_ref[0, 3:6]
        r2_x_ref, r2_y_ref, r2_z_ref = position_ref[0, 6:9]
        r3_x_ref, r3_y_ref, r3_z_ref = position_ref[0, 9:12]
        r4_x_ref, r4_y_ref, r4_z_ref = position_ref[0, 12:15]
        line_arm1_ref, = ax.plot([c_x_ref, r1_x_ref], [c_y_ref, r1_y_ref], [c_z_ref, r1_z_ref], linewidth=0.7,
                                 color='gray', marker='o', markersize=1, alpha=0.7)
        line_arm2_ref, = ax.plot([c_x_ref, r2_x_ref], [c_y_ref, r2_y_ref], [c_z_ref, r2_z_ref], linewidth=0.7,
                                 color='gray', marker='o', markersize=1, alpha=0.7)
        line_arm3_ref, = ax.plot([c_x_ref, r3_x_ref], [c_y_ref, r3_y_ref], [c_z_ref, r3_z_ref], linewidth=0.7,
                                 color='gray', marker='o', markersize=1, alpha=0.7)
        line_arm4_ref, = ax.plot([c_x_ref, r4_x_ref], [c_y_ref, r4_y_ref], [c_z_ref, r4_z_ref], linewidth=0.7,
                                 color='gray', marker='o', markersize=1, alpha=0.7)

        # time label
        time_template = 'time = %.2fs'
        time_text = ax.text2D(0.66, 0.55, "time", transform=ax.transAxes)

        # customize
        if state_traj_ref is not None:
            plt.legend([line_traj, line_traj_ref], ['learned', 'OC solver'], ncol=1, loc='best',
                       bbox_to_anchor=(0.35, 0.25, 0.5, 0.5))

        def update_traj(num):
            # customize
            time_text.set_text(time_template % (num * dt))

            # trajectory
            line_traj.set_data(position[:num, 0], position[:num, 1])
            line_traj.set_3d_properties(position[:num, 2])

            # uav
            c_x, c_y, c_z = position[num, 0:3]
            r1_x, r1_y, r1_z = position[num, 3:6]
            r2_x, r2_y, r2_z = position[num, 6:9]
            r3_x, r3_y, r3_z = position[num, 9:12]
            r4_x, r4_y, r4_z = position[num, 12:15]

            line_arm1.set_data_3d([c_x, r1_x], [c_y, r1_y],[c_z, r1_z])
            #line_arm1.set_3d_properties()

            line_arm2.set_data_3d([c_x, r2_x], [c_y, r2_y],[c_z, r2_z])
            #line_arm2.set_3d_properties()

            line_arm3.set_data_3d([c_x, r3_x], [c_y, r3_y],[c_z, r3_z])
            #line_arm3.set_3d_properties()

            line_arm4.set_data_3d([c_x, r4_x], [c_y, r4_y],[c_z, r4_z])
            #line_arm4.set_3d_properties()

            # trajectory ref
            num=sim_horizon-1
            line_traj_ref.set_data_3d(position_ref[:num, 0], position_ref[:num, 1],position_ref[:num, 2])
            #line_traj_ref.set_3d_properties()

            # uav ref
            c_x_ref, c_y_ref, c_z_ref = position_ref[num, 0:3]
            r1_x_ref, r1_y_ref, r1_z_ref = position_ref[num, 3:6]
            r2_x_ref, r2_y_ref, r2_z_ref = position_ref[num, 6:9]
            r3_x_ref, r3_y_ref, r3_z_ref = position_ref[num, 9:12]
            r4_x_ref, r4_y_ref, r4_z_ref = position_ref[num, 12:15]

            line_arm1_ref.set_data_3d([c_x_ref, r1_x_ref], [c_y_ref, r1_y_ref],[c_z_ref, r1_z_ref])
            #line_arm1_ref.set_3d_properties()

            line_arm2_ref.set_data_3d([c_x_ref, r2_x_ref], [c_y_ref, r2_y_ref],[c_z_ref, r2_z_ref])
            #line_arm2_ref.set_3d_properties()

            line_arm3_ref.set_data_3d([c_x_ref, r3_x_ref], [c_y_ref, r3_y_ref],[c_z_ref, r3_z_ref])
            #line_arm3_ref.set_3d_properties()

            line_arm4_ref.set_data_3d([c_x_ref, r4_x_ref], [c_y_ref, r4_y_ref],[c_z_ref, r4_z_ref])
            #line_arm4_ref.set_3d_properties()

            return line_traj, line_arm1, line_arm2, line_arm3, line_arm4, \
                   line_traj_ref, line_arm1_ref, line_arm2_ref, line_arm3_ref, line_arm4_ref, time_text

        ani = animation.FuncAnimation(fig, update_traj, sim_horizon, interval=dt*1000, blit=True)

        if save_option != 0:
            Writer = animation.writers['ffmpeg']
            writer = Writer(fps=10, metadata=dict(artist='Me'), bitrate=-1)
            ani.save('case2'+title + '.mp4', writer=writer, dpi=300)
            print('save_success')

        plt.show()

    def plot_position(self,state_traj,dt = 0.1):
        fig, axs = plt.subplots(3)
        fig.suptitle('position vs t')
        N = len(state_traj[:,0])
        x = np.arange(0,N*dt,dt)
        axs[0].plot(x,state_traj[:,0])
        axs[1].plot(x,state_traj[:,1])
        axs[2].plot(x,state_traj[:,2])
        plt.show()
        
    def plot_velocity(self,state_traj,dt = 0.1):
        fig, axs = plt.subplots(3)
        fig.suptitle('velocity vs t')
        N = len(state_traj[:,0])
        x = np.arange(0,N*dt,dt)
        axs[0].plot(x,state_traj[:,3])
        axs[1].plot(x,state_traj[:,4])
        axs[2].plot(x,state_traj[:,5])
        plt.show()

    def plot_rd(self,state_traj,dt = 0.1):
        fig, axs = plt.subplots(3)
        fig.suptitle('attitude vs t')
        N = len(state_traj[:,0])
        x = np.arange(0,N*dt,dt)
        axs[0].plot(x,state_traj[:,6])
        axs[1].plot(x,state_traj[:,7])
        axs[2].plot(x,state_traj[:,8])
        plt.show()

    def plot_input(self,control_traj,dt = 0.1):
        N = int(len(control_traj[:,0]))
        x = np.arange(0,round(N*dt,1),dt)
        fig = plt.figure(2)
        fig.suptitle('control commands vs iterations')
        ax1 = fig.add_subplot(2,1,1)
        ax1.plot(x,control_traj[:,0],color = 'b', label = 'wx')
        ax1.plot(x,control_traj[:,1],color = 'r', label = 'wy')
        ax1.plot(x,control_traj[:,2],color = 'y', label = 'wz')
        ax1.set_ylim([-6,6])        
        ax1.legend()
        ax2 = fig.add_subplot(2,1,2)
        ax2.plot(x,control_traj[:,3],color = 'g', label = 'thrust') 
        ax2.set_ylim([0,50])
        ax2.legend()
        plt.show()




    def dir_cosine(self, q):
        C_B_I = vertcat(
            horzcat(1 - 2 * (q[2] ** 2 + q[3] ** 2), 2 * (q[1] * q[2] + q[0] * q[3]), 2 * (q[1] * q[3] - q[0] * q[2])),
            horzcat(2 * (q[1] * q[2] - q[0] * q[3]), 1 - 2 * (q[1] ** 2 + q[3] ** 2), 2 * (q[2] * q[3] + q[0] * q[1])),
            horzcat(2 * (q[1] * q[3] + q[0] * q[2]), 2 * (q[2] * q[3] - q[0] * q[1]), 1 - 2 * (q[1] ** 2 + q[2] ** 2))
        )
        return C_B_I

    def q2R(self, q):
        R = 1/(1+q[0]**2+q[1]**2+q[2]**2) * vertcat(
            horzcat(1+q[0]**2-q[1]**2-q[2]**2, 2*(-q[2]+q[1]*q[0]), 2*(q[1]+q[0]*q[2])),
            horzcat(2*(q[2]+q[0]*q[1]), 1-q[0]**2+q[1]**2-q[2]**2, 2*(-q[0]+q[1]*q[2])),
            horzcat(2*(-q[1]+q[2]*q[0]), 2*(q[0]+q[1]*q[2]), 1-q[0]**2-q[1]**2+q[2]**2),
        )
        return R

    def jaco(self,q):
        v_cross = 2/(1+q[0]**2+q[1]**2+q[2]**2) * vertcat(
            horzcat(1, q[2], -q[1]),
            horzcat(-q[2], 1, q[0]),
            horzcat(q[1], -q[0], 1)
        )
        return v_cross
    

    def skew(self, v):
        v_cross = vertcat(
            horzcat(0, -v[2], v[1]),
            horzcat(v[2], 0, -v[0]),
            horzcat(-v[1], v[0], 0)
        )
        return v_cross

    def omega(self, w):
        omeg = vertcat(
            horzcat(0, -w[0], -w[1], -w[2]),
            horzcat(w[0], 0, w[2], -w[1]),
            horzcat(w[1], -w[2], 0, w[0]),
            horzcat(w[2], w[1], -w[0], 0)
        )
        return omeg

    def quaternion_mul(self, p, q):
        return vertcat(p[0] * q[0] - p[1] * q[1] - p[2] * q[2] - p[3] * q[3],
                       p[0] * q[1] + p[1] * q[0] + p[2] * q[3] - p[3] * q[2],
                       p[0] * q[2] - p[1] * q[3] + p[2] * q[0] + p[3] * q[1],
                       p[0] * q[3] + p[1] * q[2] - p[2] * q[1] + p[3] * q[0]
                       )
def toQuaternion(angle, dir):
    if type(dir) == list:
        dir = numpy.array(dir)
    dir = dir / numpy.linalg.norm(dir)
    quat = numpy.zeros(4)
    quat[0] = math.cos(angle / 2)
    quat[1:] = math.sin(angle / 2) * dir
    return quat.tolist()

def rp2rd(angle, dir):
    if type(dir) == list:
        dir = numpy.array(dir)
    q = dir*math.tan(angle/2)
    return q.tolist()

# normalized verctor
def normalizeVec(vec):
    if type(vec) == list:
        vec = np.array(vec)
    vec = vec / np.linalg.norm(vec)
    return vec


def quaternion_conj(q):
    conj_q = q
    conj_q[1] = -q[1]
    conj_q[2] = -q[2]
    conj_q[3] = -q[3]
    return conj_q