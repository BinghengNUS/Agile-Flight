"""
Copy and paste the content of this file in the main function (mode 2) of the ROS code
=====================================================================================
Interface data:
--------------
Input (from ROS): position, velocity (both in inertial frame), and quaternion
Output (to ROS): total thrust and angular velocity (in body frame) 
=====================================================================================
Wang, Bingheng, May 25th, 2022
"""
from re import U
from quad_policy import *


# sample step
dt_sample = 0.05 # replace this with the true sampling step in ROS
# define the narrow window, others remain the default
quad1 = run_quad(point1 = [-0.5,0, 0.5],point2 = [-0.3,0,0.6],point3 = [-0.3,0,0.5],point4 = [-0.5,0,0.4])
# get position from ROS
x        = 0 # replace the right-hand-side with the corresponding ROS topic
y        = 0
z        = 0
position = [x,y,z] 
# get velocity from ROS
vx       = 0
vy       = 0
vz       = 0
velocity = [vx,vy,vz]
# get quaternion from ROS
q0       = 0 # corresponds to pose.orientation.x
q1       = 0 # corresponds to pose.orientation.y
q2       = 0 # corresponds to pose.orientation.z
q3       = 1 # corresponds to pose.orientation.w
q        = [q3, q0, q1, q2]
# convert to Rodrigues parameters
rd       = [q0/q3,q1/q3,q2/q3]
# system state (9 dimensions)
state    = position + velocity + rd
# last control input, the initial value is zero by default
Ulast    = [0,0,0,0] # put this outside the iteration loop
# time
time     = 0 # put this outside the iteration loop
# implement MPC in a receding horzion manner
u = quad1.get_input(state,[-4.51535303e-01, -2.33792041e-04 , 5.26563852e-01],[0.0242507 , 0.04983589, 0.01478296],1.0-time,Ulast)
# update the last control effort
Ulast = u
# update time
time += dt_sample
# get the total thrust
f     = u[3]

