"""
Copy and paste the content of this file in the main function (mode 2) of the ROS code
=====================================================================================
Interface data:
--------------
Input (from ROS): position, velocity (both in inertial frame), and quaternion
Output (to ROS): total thrust and angular velocity (in body frame) 
=====================================================================================
Wang, Bingheng, May 25th, 2022
"""
from quad_policy import *

# define the narrow window, others remain the default
quad1 = run_quad(point1 = [-0.5,0, 0.5],point2 = [-0.3,0,0.6],point3 = [-0.3,0,0.5],point4 = [-0.5,0,0.4])
# get position from ROS
x        = 0 # replace the right-hand-side with the corresponding ROS topic
y        = 0
z        = 0
position = [x,y,z] 